package Modelo

class dataclassTickets (
val Ticketnum: String,
val TituloTicket: String,
    val Descripcion: String,
    val Responsable: String,
    val EmailAutor: String,
    val TelefonoAutor: String,
    val Ubicacion: String,
    val Estado: String


)